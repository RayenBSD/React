import { Component } from 'react';
import './App.css';
import Info from "./Info/Info";
import memberInfo from './member';


class App extends Component{
  constructor () {
    super()
    this.state = {
      memberInfo: memberInfo,
      counter: 0,
    }

    this.addCounter = this.addCounter.bind(this);
  }

  addCounter () {
    console.log(this.state.counter);
    if (this.state.counter === (this.state.memberInfo.length)-1) {
      this.setState (prevState => {
        return {
          memberInfo: prevState.memberInfo,
          counter: 0
        }
      });
    }
    else {
      this.setState (prevState => {
        return {
          memberInfo: prevState.memberInfo,
          counter: prevState.counter+1
        }
      });
    }
  }

  /*mapping (m) {
    let members = m.map(member => <Info 
                                    img={member.img}
                                    name={member.name}
                                    job={member.job}
                                    email={member.email}
                                    web={member.web}
                                    number={member.number}
                                  />
    );
    return members;
  }*/
  
  render () {
    return (
      <div>
        <button onClick={this.addCounter}>Click Me!</button>
        <Info 
          img={this.state.memberInfo[this.state.counter].img}
          name={this.state.memberInfo[this.state.counter].name}
          job={this.state.memberInfo[this.state.counter].job}
          email={this.state.memberInfo[this.state.counter].email}
          web={this.state.memberInfo[this.state.counter].web}
          number={this.state.memberInfo[this.state.counter].number}
        />
      </div>  
    );
  }
}

export default App;
