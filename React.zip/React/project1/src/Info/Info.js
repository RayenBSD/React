import React from "react";
import { Component } from "react";
import "./Info.css"

class Info extends Component {

    render () {

        let styleNum = {}, styleWeb = {}, styleEmail = {};
        let num, email, web;

        //Email
        if (this.props.email !== "") {
            styleEmail = {display: "block"}; 
            email = `Email: ${this.props.email}`;
        }
        else {
            styleEmail = {display: "inline"};
            email = '';
        }
        //Website
        if (this.props.web !== "") {
            styleWeb = {display: "block"}; 
            web = `Web: ${this.props.web}`;
        }
        else {
            styleWeb = {display: "inline"};
            web = '';
        }
        //Phone Number
        if (this.props.number !== "") {
            styleNum = {display: "block"}; 
            num = `Phone: ${this.props.number}`;
        }
        else {
            styleNum = {display: "inline"};
            num = '';
        }
        
        return (
            <div>
                <img src={this.props.img} alt={`${this.props.name} image`}/>
                <h4>{this.props.name}</h4>
                <h5>{this.props.job}</h5>
                <p style={styleEmail}>{email}</p>
                <p style={styleWeb}>{web}</p>
                <p style={styleNum}>{num}</p>
            </div>
        );
    }
}

export default Info;