import React from "react";
import { Component } from "react";
import Description from "../Components/Description/Description";
import Company from "../Components/Company/Company";

class Body extends Component {
    render () {
        return (
            <div>
                <Description />
                <Company />
            </div>
        );
    }
}

export default Body;