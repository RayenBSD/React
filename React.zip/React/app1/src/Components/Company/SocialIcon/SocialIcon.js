import React from "react";
import { Component } from "react";

class SocialIcon extends Component {
    render () {
        return (
            <li className="list-group-item">
                <input type="checkbox" id={this.props.media.id}/>
                <label htmlFor={this.props.media.id}>{this.props.media.name}</label>
            </li>
        );
    }
}

export default SocialIcon;