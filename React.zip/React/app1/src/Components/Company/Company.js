import React from "react";
import { Component } from "react";
import "./Company.css"
import SocialIcon from "./SocialIcon/SocialIcon";

class Company extends Component {
    render () {
        return (
            <div>
                <ul className="list-group">
                    <SocialIcon media = {{
                        name: "Facebook",
                        id: "facebook"
                    }}/>
                    <SocialIcon media = {{
                        name: "Youtube",
                        id: "youtube"
                    }}/>
                    <SocialIcon media = {{
                        name: "Instagrame",
                        id: "instagrame"
                    }}/>
                </ul>
            </div>
        );
    }
}

export default Company;