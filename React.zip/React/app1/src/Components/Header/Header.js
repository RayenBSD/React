import React, { Component } from 'react';
import "./Header.css"

let title = "";
let client = 'p';

class Header extends Component {

    render () {

        title = (client === 'd') ? "Designer" : "Programming";

        return (
            <div className="navbar bg-dark rounded">
                <h1 className="text-white">{title} is my life</h1>
            </div>
        );        
    }
}

export default Header;