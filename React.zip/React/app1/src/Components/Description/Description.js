import React from "react";
import { Component } from "react";
import "./Description.css"

class Description extends Component {
    render () {
        let des = "";
        let client = 'p';
        des = (client === 'd') ? "Graphic" : "programmer"
        return (
            <p>
                {`${des} and web design are far more than a job for me.`}
            </p>
        );
    }
}
export default Description;