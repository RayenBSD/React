import './App.css';
import Header from "./Components/Header/Header"
import Body from './Body/Body';
import React, { Component } from 'react';

class App extends Component {
    render () {
        return (
            <div className="container">
                <Header />
                <Body />
            </div>
        );        
    }

}

export default App;
